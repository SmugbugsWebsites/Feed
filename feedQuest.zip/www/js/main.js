forge.logging.info("Add JavaScript to js/main.js!");
