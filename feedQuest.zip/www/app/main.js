function showError(msg, type){
	alert(msg);
}

function getStarted(){
	route_section("feed03");
}

function aside(){
	if(!$('aside#feed03-dropmenu').hasClass('show')) {
		$('aside#feed03-dropmenu').addClass('show');
		$('.milkytransparent_layer').show();
		$('section').addClass('aside');
		$('.right').animate({
			left: "0"
		});
	} else {
		$('aside#feed03-dropmenu').removeClass('show');
		$('.milkytransparent_layer').hide();
		$('section').removeClass('aside');
		$('.right').animate({
			left: "-270px"
		});
	}
	event.stopPropagation();
}

function SignInUser(){
	route_section("feed08");
	$('input[type=text]').val('');
	$('input[type=email]').val('');
	$('input[type=tel]').val('');
	$('input[type=password]').val('');
}

function RegisterUser(){
	route_section("feed09");
	$('input[type=text]').val('');
	$('input[type=email]').val('');
	$('input[type=tel]').val('');
	$('input[type=password]').val('');
}

function ComingSoon(type){
	alert(type);
}

function LogOutUser(){
	RETRYAJAXURL  = '';
	RETRYAJAXDATA = '';
	RETRYAJAXASYNC = 0;
	RETRYAJAXFUNCTION = '';
	url;
	jsonData;
	FbId = '';
	FbName = '';
	FbEmail = '';
	FbToken = '';
	GoogleId = '';
	GoogleName = '';
	GoogleEmail = '';
	GoogleId = '';
	ImgUser = '';
	loginVia = '';
	userID = '';
	userName = '';
	userEmail = '';
	userImage = '';
	userNature = '';
	notificationstart = '';
	notificationend = '';
	route_section('feed08');
	window.localStorage.removeItem("loginCache");
	$('input[type=text]').val('');
	$('input[type=email]').val('');
	$('input[type=tel]').val('');
	$('input[type=password]').val('');
	
}

function SignInDirect(type){
	jsonData = '';
	var id = '';
	if (type == 'fb'){
		id = FbId;
		var jsonData = {
			'name': FbName,
			'fbId': FbId,
			'pimg': ImgUser,
			'email': FbEmail
		};
	} else if (type == 'google'){
		id = GoogleId;
		var jsonData = {
			'name': GoogleName,
			'googleid': GoogleId,
			'pimg': ImgUser,
			'email': GoogleEmail
		};
	}
	jsonData['id'] = id;
	jsonData['type'] = type;
	var url = "Users/chkUserExistences";
	
	var response = callAjax(url,jsonData);
	
	if(response.C == 100){
		//NEW USERS CREATE
		var url = "Users/createUser";
		var response = callAjax(url,jsonData);
		if(response.C == 100){
			//user create
			userID = response.R;
			completeProfile();
		} else {
			//insert error
			showError('Try to signUp again later.',0);
			return false;
		}		
	} else if(response.C == 101) {
		//NEW USERS ALREADY CREATE
		var result = response.R;
		userID = result.id;
		if(result.profilestatus == 0){
			//profile incomplete
			completeProfile();	
		} else if(result.profilestatus == 1){
			//profile complete to dashboard
			setUserdashboard();
			if(result.usersProfile == 1){
				//users is manager
				userNature = 1;
			} else if(result.usersProfile == 2){
				//users is DJ
				userNature = 2;
			} else {
				//normal users
				userNature = 0;
			}
		} else if(result.profilestatus == 2){
			//users block
		} else{
			//login again
		}
	} else {
		//NO DATA GET
	}
}

function completeProfile(){
	var url = "Users/getUser";
	var jsonData = {'usersID':userID};
	var response = callAjax(url,jsonData);
	
	if(response.C == 100){
		route_section("feed09");
		$('input[type=text]').val('');
		$('input[type=email]').val('');
		$('input[type=tel]').val('');
		$('input[type=password]').val('');
		var result = response.R;
		$('#username').val(result.name);
		if(result.contact == 0){
			$('#usercontact').val('');
		} else {
			$('#usercontact').val(result.contact);
		}
		
		if(result.email != ''){
			$('#useremail').attr('readonly','readonly');
			$('#useremail').val(result.email);
		} else {
			$('#useremail').removeAttr('readonly');
			$('#useremail').val('');
		}
		
		$('#userpassword').val('');
		$('#usercpassword').val('');
	}
}

function registerUser(){
	var uname = $('#username').val();
	var ucontact = $('#usercontact').val();
	var uemail = $('#useremail').val();
	var upass = $('#userpassword').val();
	var ucpass = $('#usercpassword').val();
	if(uname == ''){
		$('#username').focus();
		showError('Enter name',0);
		return false;
	} else if(ucontact == ''){
		$('#usercontact').focus();
		showError('Enter contact number',0);
		return false;
	} else if(ucontact.length != 10){
		$('#usercontact').focus();
		showError('Enter correct contact number',0);
		return false;
	} else if(uemail == ''){
		$('#useremail').focus();
		showError('Enter email',0);
		return false;
	} else if(!(isValidEmailAddress(uemail))){
		$('#useremail').focus();
		showError('Enter valid email',0);
		return false;
	} else if(upass == ''){
		$('#userpassword').focus();
		showError('Enter password',0);
		return false;
	} else if(upass <= 5){
		$('#userpassword').focus();
		showError('Enter password length less tha 6',0);
		return false;
	} else if(ucpass == ''){
		$('#usercpassword').focus();
		showError('Enter confirm password',0);
		return false;
	} else if(ucpass !== upass){
		$('#usercpassword').focus();
		showError('Password not match',0);
		return false;
	} else {
		var url = "Users/userCreate";
		var jsonData = {'usersID':userID,'uname':uname,'ucontact':ucontact,'uemail':uemail,'upass':upass};
		var response = callAjax(url,jsonData);
		if(response.C == 100){
			userID = response.R;
			setUserdashboard();
		} else if(response.C == 106){
			// contact already register
			$('#usercontact').focus();
			showError('Enter contact number already register with us.',0);
			return false;
		} else if(response.C == 105){
			// email already register
			$('#useremail').focus();
			showError('Enter email already register with us.',0);
			return false;
		} else {
			// error while registration or when update already register user
			showError('Try to register again, there is some error in your connection or something else.',0);
			return false;
		}
	}
}

function getuserdetailId(id){
	var url = "Users/getUserInfo";
	var jsonData = {'usersID':userID};
	callAjaxFunction(url,jsonData,getuserdetailIdASYNC);
}

var getuserdetailIdASYNC = function(response){
	window.localStorage.removeItem("loginCache");
	if(response.C == 100){
		var result = response.R;
		userID = result.id;
		userName = result.name;
		userEmail = result.email;
		userImage = result.pimage;
		userContact = result.contact;
		userNature = result.usersProfile;
		var data = {'userNature':userNature,'userContact':userContact,'userImage':userImage,'userEmail':userEmail,'userName':userName,'userID':userID};
		window.localStorage.setItem("loginCache", JSON.stringify(data));
	} else {
		showError('Session expire. Login again');
		LogOutUser();
	}
}

function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
}

function setUserdashboard(){
	if(userID != ''){
		getuserdetailId(userID);
		push_register();
	}
	route_section("feed03");
	seTmenu();
}

function seTmenu(){
	if(userID != ''){
		if(userNature == 1){
			html = '<li><a href="javascript:setUserdashboard();">Home <span></span></a></li>\
			<li><a href="javascript:eventsCreated();">Events <span></span></a></li>\
			<li><a href="javascript:feedbacks();">Feeds <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'terms\');">Terms <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'faq\');">FAQ <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'about\');">About <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'help\');">Help <span></span></a></li>\
			<li><a href="javascript:LogOutUser();">LOGOUT <span></span></a></li>';
		} else if(userNature == 2){
			html = '<li><a href="javascript:setUserdashboard();">Home <span></span></a></li>\
			<li><a href="javascript:eventsCreated();">Events <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'terms\');">Terms <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'faq\');">FAQ <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'about\');">About <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'help\');">Help <span></span></a></li>\
			<li><a href="javascript:LogOutUser();">LOGOUT <span></span></a></li>';
		} else {
			html = '<li><a href="javascript:setUserdashboard();">Home <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'terms\');">Terms <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'faq\');">FAQ <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'about\');">About <span></span></a></li>\
			<li><a href="javascript:ComingSoon(\'help\');">Help <span></span></a></li>\
			<li><a href="javascript:LogOutUser();">LOGOUT <span></span></a></li>';
		}
	} else {
		html = '<li><a href="javascript:setUserdashboard();">Home <span></span></a></li>\
		<li><a href="javascript:SignInUser();">Login <span></span></a></li>\
		<li><a href="javascript:RegisterUser();">Register <span></span></a></li>\
		<li><a href="javascript:ComingSoon(\'terms\');">Terms <span></span></a></li>\
		<li><a href="javascript:ComingSoon(\'faq\');">FAQ <span></span></a></li>\
		<li><a href="javascript:ComingSoon(\'about\');">About <span></span></a></li>\
		<li><a href="javascript:ComingSoon(\'help\');">Help <span></span></a></li>';
		
	}
	$('#menuOption').html(html);
}

function loginUser(){
	var email  = $('#uemail').val();
	var upass = $('#upass').val();
	var url = 'Users/loginuser';
	var jsonData = {'uemail':email,'upass':upass};
	var response = callAjax(url,jsonData);
	if(response.C == 100){
		var result = response.R;
		userID = result.id;
		if(result.profilestatus == 1){
			//profile complete to dashboard
			setUserdashboard();
			if(result.usersProfile == 1){
				//users is manager
				userNature = 1;
			} else if(result.usersProfile == 2){
				//users is DJ
				userNature = 2;
			} else {
				//normal users
				userNature = 0;
			}
		} else if(result.profilestatus == 2){
			//users block
		} else{
			//login again
		}
	} else {
		showError('Username or password is wrong.',0);
		return false;
	}
}

function scan(){
	cordova.plugins.barcodeScanner.scan(
		function (result) {
			QrData(result.text);
		},function (error) {
			//alert("Scanning failed: " + error);
		},{
			// preferFrontCamera : false, iOS and Android
			// torchOn: false, Android, launch with the torch switched on (if available)
			showFlipCameraButton : true,// iOS and Android
			prompt : " ", // Android
			showTorchButton : true, // iOS and Android
			resultDisplayDuration: 500, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
			formats : "QR_CODE", // default: all but PDF_417 and RSS_EXPANDED
			orientation : "portrait", // Android only (portrait|landscape), default unset so it rotates with the device
			disableAnimations : true, // iOS
			disableSuccessBeep: false // iOS
		}
	);
}

function QrData(txt){
	var scanData = JSON.parse(txt);
	if (isRealValue(scanData)) {
		route_section('feed04');
		setTimeout(function(){
			$('#placeqr').val(scanData.placename);
			placeLat = scanData.lat;
			placeLng = scanData.lng;
			placeUid = scanData.placeid;
			managerId = scanData.managerId;
			if(scanData.DJ == 0){
				$('#requestuser').hide();
			} else {
				$('#requestuser').show();
			}
		},200);
	} else {
		showError('Scan QR again. their is problem in scaning QR');
	}
}

function feedQrplace(){
	verfiyLocation();
	setTimeout(function(){
		route_section('feed06');
	},500);
}

function submitFeedback(){
	var name = $('#usersfeedname').val();
	var email = $('#usersfeedemail').val();
	var contact = $('#usersfeedcontact').val();
	var feed = $('textarea#usersfeedtext').val();
	
	if(email != ''){
		if(!(isValidEmailAddress(email))){
			$('#usersfeedemail').focus();
			showError('Enter valid email',0);
			return false;
		}
	}
	var url = 'Users/sendFeed';
	var jsonData = {'feed':feed,'placeUid':placeUid,'contact':contact,'name':name,'userId':userID,'managerId':managerId,'email':email};
	callAjaxFunction(url,jsonData,submitFeedbackASYNC);
}

var submitFeedbackASYNC = function(){
	route_section('feed04');
}

function closefeedbackdone(){
	$('#feed06').remove();
	$('#feed04').remove();
	$('#feed07').hide();
	setUserdashboard();
}

function songPush(){
	verfiyLocation();
	setTimeout(function(){
		route_section('feed11');
	},500);
}

function submitSongRequest(){
	var name = $('#userssongname').val();
	var email = $('#userssongemail').val();
	var contact = $('#userssongcontact').val();
	var song = $('#userssong').val();
	var artist = $('#userssongartist').val();
	
	if(email != ''){
		if(!(isValidEmailAddress(email))){
			$('#userssongemail').focus();
			showError('Enter valid email',0);
			return false;
		}
	} else if (contact != ''){
		if(contact.length != 10){
			$('#userssongcontact').focus();
			showError('Enter valid contact',0);
			return false;
		}
	}
	
	var url = 'Users/sendSong';
	var jsonData = {'song':song,'artist':artist,'placeUid':placeUid,'contact':contact,'name':name,'userId':userID,'managerId':managerId,'email':email};
	callAjaxFunction(url,jsonData,submitSongRequestASYNC);
}

var submitSongRequestASYNC = function(){
	route_section('feed04');
}

function deg2rad(deg) {
	return deg * (Math.PI / 180)
}

var verf;
function verfiyLocation(){
	var width = 0;
	clearInterval(verf);
	$('#loationMsg').removeClass('error');
	$('#loationMsg').html('We are verifying your location');
	$('#feed05').show();
	var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(LatiTude - placeLat); // deg2rad below
    var dLon = deg2rad(LongiTude - placeLng);
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(placeLat)) * Math.cos(deg2rad(placeLng)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = (R * c).toFixed(1); // Distance in km
	if ($.isNumeric(d) == false) {
		d = 1001;
	}
	alert(placeLat+'---'+placeLng);
	alert(LatiTude+'---'+LongiTude);
	alert(d);
	verf = setInterval(function() {
		if (width == 101) {
			clearInterval(verf);
			if ($.isNumeric(d)) {
				if (d <= 0.3) {
					$('#feed05').hide();
				} else if (d > 0.3) {
					$('#loationMsg').addClass('error');
					$('#loationMsg').html('We are not verifying your location.');
				}
			}
		} else {
			$('#loaderVerifying').css('width', width + '%');
		}
		width += 1;
	}, 100);
}

function feedbacks(){
	
}

function eventsCreated(){
	
}