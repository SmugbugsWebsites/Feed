var DevicePlatform;
var PushRegisterCode;
var isAppInbackground;
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
	document.addEventListener("pause", onPause, false);
	document.addEventListener("resume", onResume, false);
	DevicePlatform = device.platform;
	isAppInbackground = 0;
	chkGps();
}

function chkGps(){
	cordova.plugins.diagnostic.isGpsLocationEnabled(function(enabled){
		enabled ? getlocation() : openloaction();
	}, function(error){
		alert("The following error occurred: "+error);
	});
}

function alertDismissed() {
	if(DevicePlatform == 'Android'){
		cordova.plugins.diagnostic.switchToLocationSettings();
	} else {
		cordova.plugins.diagnostic.switchToSettings();
	}
}

function openloaction(){
	navigator.notification.alert(
		'Enable your location service to continue.',  // message
		alertDismissed,         // callback
		'ENABLE LOCATION',            // title
		'Setting'                  // buttonName
	);
}

function getlocation(){
    var watchID = navigator.geolocation.watchPosition(onSuccess, onError, { timeout: 10000,enableHighAccuracy: true });
}

function onSuccess(position) {
	LatiTude = position.coords.latitude;
	LongiTude = position.coords.longitude;
	//alert(LatiTude+'--------'+LongiTude);
}

function onError(error) {
	chkGps();
}

function onPause(){
	isAppInbackground = 1;
}

function onResume(){
	isAppInbackground = 0;
	chkGps();
}

function push_register() {
	if (DevicePlatform == "iOS") {
		PUSH = PushNotification.init({
			"android": {
				"senderID": "751120544832",
				"icon": "pushicon",
				"iconColor": "white"
			},
			"ios": {
				"alert": "true",
				"badge": "true",
				"sound": "true"
			},
			"windows": {}
		});
		PUSH.on('registration', function(data) {
			PushRegisterCode = data.registrationId;
		});
		PUSH.on('notification', function(data) {
			var pushData = {
				"title": data.additionalData.title,
				"message": data.additionalData.message,
				"additionalData": {
					"foreground": data.additionalData.foreground,
					"custom": {
						"type": data.additionalData.type,
						"id": data.additionalData.id,
						"userid": data.additionalData.friendid
					}
				}
			};
			notifyListener(pushData);
			IsPushNotify = 1;
		});
	} else if(DevicePlatform == "Android") {
		FCMPlugin.getToken(function(token) {
			PushRegisterCode = token;
			var url = "Users/pushToken";
			var jsonData = {'userID':userID,'token':PushRegisterCode,'platform':DevicePlatform};
			callAjaxFunction(url,jsonData,tokenASYNC);
		}, function(err) {
			console.log('error retrieving token: ' + err);
		});
		
		FCMPlugin.onNotification(function(data) {
			if (data.wasTapped) {
				var foreground = false;
			} else {
				var foreground = true;
			}
			var pushData = {
				"additionalData": {
					"foreground": foreground,
					"custom": {
						"type": data.type,
						"id": data.id,
						"userid": data.friendid
					}
				}
			};
			notifyListener(pushData);
			//alert(JSON.stringify(data));
		}, function(msg) {
			//alert('onNotification callback successfully registered: ' + msg);
		}, function(err) {
			//alert('Error registering onNotification callback: ' + err);
		});
	}
}

var tokenASYNC = function (response){
	//alert(JSON.stringify(response));
}

function notifyListener(data) {
	alert(JSON.stringify(data));
}